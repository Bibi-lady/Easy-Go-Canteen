
package Controller;

import ac.entities.Employee;
import ac.entities.bl.EmployeeFacadeLocal;
import java.io.IOException;
import java.util.List;
import javax.ejb.EJB;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class DepartmentEmployeesServlet extends HttpServlet {

    @EJB
    private EmployeeFacadeLocal efl;
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
         String department = request.getParameter("department");
        List<Employee> employees = efl.getEmployee(department);
        
        request.setAttribute("employees", employees);
        request.setAttribute("department", department);
      RequestDispatcher disp =  request.getRequestDispatcher("departmentEmployees.jsp");
                disp.forward(request, response);
        
    }

   

}
