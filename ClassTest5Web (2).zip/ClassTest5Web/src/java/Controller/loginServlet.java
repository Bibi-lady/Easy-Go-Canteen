package Controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


public class loginServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        String username = request.getParameter("j_username"); 
        String password = request.getParameter("j_password"); 
        
        try {
            // Authenticate using request.login() which integrates with GlassFish security
            request.login(username, password);
            
            HttpSession session = request.getSession();
            session.setAttribute("username", username);
            
            // Get the user's roles from the request
            if (request.isUserInRole("manager")) {
                session.setAttribute("role", "manager");
            } else if (request.isUserInRole("secretary")) {
                session.setAttribute("role", "secretary");
            }
            
            response.sendRedirect("menu.jsp");
            
        } catch (ServletException e) {
            // Authentication failed
            request.setAttribute("error", "Invalid username or password");
            request.getRequestDispatcher("login.jsp").forward(request, response);
        }
    }
}