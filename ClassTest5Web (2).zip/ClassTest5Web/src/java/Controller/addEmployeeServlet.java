package Controller;

import ac.entities.Employee;
import ac.entities.bl.EmployeeFacadeLocal;
import java.io.IOException;
import javax.ejb.EJB;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class addEmployeeServlet extends HttpServlet {

    @EJB
    private EmployeeFacadeLocal employeeFacade;  

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        try {
           
            String department = request.getParameter("department");
            double salary = Double.parseDouble(request.getParameter("salary"));
            
            
            if (department == null || department.trim().isEmpty()) {
                throw new ServletException("Department cannot be empty");
            }
            
       
            Employee employee = new Employee();
            employee.setDepartment(department);
            employee.setSalary(salary);
            
            employeeFacade.addEmployee(employee);
            
           
            request.setAttribute("employee", employee);
           
            
        } catch (NumberFormatException e) {
            request.setAttribute("error", "Invalid salary format: " + e.getMessage());
        } catch (Exception e) {
            request.setAttribute("error", "Failed to add employee: " + e.getMessage());
        }
        
       
       RequestDispatcher disp = request.getRequestDispatcher("add_outcome.jsp");
       disp.forward(request, response);
    }
}